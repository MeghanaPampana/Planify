import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Sidebar = () => {
  const navigate = useNavigate();

  const handleSignOut = (event) => {
    event.preventDefault();
    navigate('/');
  };

  return (
    <div>
      <div className="d-flex flex-column flex-shrink-0 p-3 bg-body-tertiary" style={{ width: '230px', height: '100vh'}}>
        <Link to="/main" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
          <svg className="bi pe-none me-2" width="40" height="32"><use xlinkHref="#bootstrap" /></svg>
          <span className="fs-4">PLANIFY</span>
        </Link>
        <hr />
        <ul className="nav nav-pills flex-column mb-auto">
          <li className="nav-item">
            <Link to="/dashboard" className="nav-link link-body-emphasis">
              <svg className="bi pe-none me-2" width="16" height="16"><use xlinkHref="#speedometer2" /></svg>
              Dashboard
            </Link>
          </li>
          <li>
            <Link to="/projects" className="nav-link link-body-emphasis">
              <svg className="bi pe-none me-2" width="16" height="16"><use xlinkHref="#file-earmark-text" /></svg>
              Projects
            </Link>
          </li>
          <li>
            <Link to="/calendar" className="nav-link link-body-emphasis">
              <svg className="bi pe-none me-2" width="16" height="16"><use xlinkHref="#calendar2-week" /></svg>
              Calendar
            </Link>
          </li>
          <li>
            <Link to="/updates" className="nav-link link-body-emphasis">
              <svg className="bi pe-none me-2" width="16" height="16"><use xlinkHref="#bell" /></svg>
              Updates
            </Link>
          </li>
          <li>
            <Link to="/profile" className="nav-link link-body-emphasis">
              <svg className="bi pe-none me-2" width="16" height="16"><use xlinkHref="#person-circle" /></svg>
              Profile
            </Link>
          </li>
          <li>
            <Link className="nav-link link-body-emphasis" onClick={handleSignOut}>
              <svg className="bi pe-none me-2" width="16" height="16"><use xlinkHref="#person-circle" /></svg>
              Sign Out
            </Link>
          </li>
        </ul>
        <hr />
      </div>
    </div>
  );
}

export default Sidebar;
