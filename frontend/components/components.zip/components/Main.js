import React from 'react';
import Sidebar from './Sidebar';
import Updates from './Updates';
import './Main.css';

const Main = () => {
  return (
    <div className="main">
      <Sidebar className="sidebar" />
      <Updates className="updates" />
    </div>
  );
};

export default Main;
