import React, { useState } from 'react';
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, addDays, isSameMonth, isSameDay } from 'date-fns';

function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());

  const renderHeader = () => {
    return (
      <thead>
        <tr>
          <th colSpan="7">
            {format(currentDate, 'MMMM yyyy')}
          </th>
        </tr>
        <tr>
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <th key={day}>{day}</th>
          ))}
        </tr>
      </thead>
    );
  };

  const renderCells = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);

    const dateFormat = 'd';
    const rows = [];
    let days = [];
    let day = startDate;

    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        const formattedDate = format(day, dateFormat);
        const cloneDay = day;
        days.push(
          <td
            key={day}
            className={`${!isSameMonth(day, monthStart) ? 'disabled' : ''} ${isSameDay(day, new Date()) ? 'selected' : ''}`}
            onClick={() => handleDateClick(cloneDay)}
          >
            {formattedDate}
          </td>
        );
        day = addDays(day, 1);
      }
      rows.push(
        <tr key={day}>{days}</tr>
      );
      days = [];
    }

    return (
      <tbody>{rows}</tbody>
    );
  };

  const handleDateClick = (day) => {
    setCurrentDate(day);
  };

  return (
    <div className="calendar-container" style={{ width: '250px' }}>
      <table className="calendar">
        {renderHeader()}
        {renderCells()}
      </table>
    </div>
  );
}

export default Calendar;