import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const Home = () => {
  return (
    <div className='home'>
      <form className="form-container">
        <div className="centered">
          <h1 className="page-title monofett-regular">PLANIFY</h1>
          <div className="button-container">
            <Link to="/login">
              <button type="submit" className="btn btn-lg btn-login">Login</button>
            </Link>
            <Link to="/register">
              <button type="submit" className="btn btn-lg btn-register">Register</button>
            </Link>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Home;
